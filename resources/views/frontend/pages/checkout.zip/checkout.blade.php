@extends('frontend.index')
@section('page-styles')
    @include('frontend.style.checkout')
    <style>
        #reason-dropdown-list {
            max-height: 220px;
            overflow-y: auto;
        }
    </style>
@stop
@section('content')
    <section class="breadcrumbs-custom">
        <div class="parallax-container" data-parallax-img="frontend/images/breadcrumbs-bg.jpg">
            <div class="breadcrumbs-custom-body parallax-content context-dark" style="min-height: 20px">
                <div class="container">
                    <h2 class="breadcrumbs-custom-title">Checkout</h2>
                </div>
            </div>
        </div>
        <div class="breadcrumbs-custom-footer">
            <div class="container">
                <ul class="breadcrumbs-custom-path">
                    <li><a href="{{route('home')}}">Home</a></li>
                    <li><a href="{{route('shop')}}">Shop</a></li>
                    <li class="active">Checkout</li>
                </ul>
            </div>
        </div>
    </section>
    <!-- Section checkout form-->
    <section class="section section-sm section-first bg-default text-md-start">
        <div class="container">
            <form class="rd-form form-checkout" method="POST" action="{{ route('checkout.submit') }}" id="checkout-form" novalidate>
                <input type="hidden" value="{{ csrf_token() }}" name="_token" />
                <div class="row row-50 justify-content-center">
                    <div class="col-md-10 col-lg-6">
                        <h3 class="fw-medium">Delivery Address</h3>

                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-wrap">
                                    <input class="form-input" id="checkout-first-name-1" type="text" name="customer_name" placeholder="Name" required
                                           value="{{ old('customer_name', $user->name ?? '') }}" />
                                    <span class="error-message text-danger" id="error-customer_name"></span>
                                </div>
                            </div>
                            <div class="col-sm-12 d-flex align-items-end">
                                <div class="form-wrap w-100" style="position: relative;">
                                    <div class="custom-select-mimic" style="position: relative;">
                                        <input type="hidden" name="area" id="reason-hidden" value="{{ old('area') }}">
                                        <button type="button" id="reason-dropdown-btn" class="form-input" style="width: 100%; text-align: left; background: #fff; border: 1px solid #ced4da; border-radius: 4px; padding: 10px; cursor: pointer;">
                                            <span id="reason-selected">{{ old('area') ? old('area') : 'Please Select Area' }}</span>
                                            <span style="float: right;">&#9662;</span>
                                        </button>
                                        <ul id="reason-dropdown-list" style="display: none; position: absolute; z-index: 10; width: 100%; background: #fff; border: 1px solid #ced4da; border-radius: 0 0 4px 4px; margin: 0; padding: 0; list-style: none;">
                                            @foreach($dhaka_areas as $area)
                                                <li class="dropdown-item" data-value="{{ $area->name }}" style="padding: 10px; cursor: pointer;">{{ $area->name }}</li>
                                            @endforeach
                                        </ul>
                                        <div id="reason-error" class="text-danger mt-1" style="display:none;">Please select an area.</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">

                            </div>
                            <div class="col-12">
                                <div class="form-wrap">
                                    <input class="form-input" id="address" type="text" name="address_details" required
                                           value="{{ old('address_details', $user->address ?? '') }}" placeholder="Address" />
                                    <span class="error-message text-danger" id="error-address_details"></span>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-wrap">
                                    <input class="form-input" id="checkout-email-1" type="email" name="email" placeholder="Email" required
                                           value="{{ old('email', $user->email ?? '') }}" />
                                    <span class="error-message text-danger" id="error-email"></span>
                                    @if ($errors->has('email'))
                                        <div class="alert alert-danger">
                                            {{ $errors->first('email') }}
                                        </div>
                                    @endif
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-wrap">
                                    <input class="form-input" id="checkout-phone-1" type="text" name="phone" placeholder="phone" required
                                           value="{{ old('phone', $user->phone ?? '') }}" />
                                    <span class="error-message text-danger" id="error-phone"></span>
                                    @if ($errors->has('phone'))
                                        <div class="alert alert-danger">
                                            {{ $errors->first('phone') }}
                                        </div>
                                    @endif
                                </div>
                            </div>

                            @php
                                $now = time();
                                $cutoffTime = strtotime(date('Y-m-d') . ' 16:00:00');
                                $today = date('Y-m-d');
                                $defaultDate = $now > $cutoffTime ? date('Y-m-d', strtotime('+1 day')) : $today;

                                $timeSlots = [
                                    '08:00 AM - 09:00 AM',
                                    '09:00 AM - 10:00 AM',
                                    '10:00 AM - 11:00 AM',
                                    '11:00 AM - 12:00 PM',
                                    '12:00 PM - 01:00 PM',
                                    '01:00 PM - 02:00 PM',
                                    '02:00 PM - 03:00 PM',
                                    '03:00 PM - 04:00 PM',
                                    '04:00 PM - 05:00 PM',
                                    '05:00 PM - 06:00 PM',
                                    '06:00 PM - 07:00 PM',
                                    '07:00 PM - 08:00 PM',
                                ];
                            @endphp

                            <div class="col-sm-6">
                                <div class="form-wrap">
                                    <input type="date" class="form-input" name="delv_d" id="delv_d" value="{{ $defaultDate }}" min="{{ $today }}" required>
                                    <span class="error-message text-danger" id="error-delv_d"></span>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-wrap" style="position: relative;">
                                    <input type="hidden" name="time" id="delv_t" value="{{ old('time') }}">
                                    <button type="button" id="delv_t-dropdown-btn" class="form-input" style="width: 100%; text-align: left; background: #fff; border: 1px solid #ced4da; border-radius: 4px; padding: 10px; cursor: pointer;">
                                        <span id="delv_t-selected">{{ old('time') ? old('time') : 'Select Delivery Time' }}</span>
                                        <span style="float: right;">&#9662;</span>
                                    </button>
                                    <ul id="delv_t-dropdown-list" style="display: none; position: absolute; z-index: 10; width: 100%; background: #fff; border: 1px solid #ced4da; border-radius: 0 0 4px 4px; margin: 0; padding: 0; list-style: none; max-height: 220px; overflow-y: auto;">
                                        @foreach($timeSlots as $slot)
                                            <li class="dropdown-item" data-value="{{ $slot }}" style="padding: 10px; cursor: pointer;">{{ $slot }}</li>
                                        @endforeach
                                    </ul>
                                    <span class="error-message text-danger" id="error-time"></span>
                                </div>
                            </div>

                            <input type="hidden" id="server-date" value="{{ $today }}">
                            <input type="hidden" id="server-time" value="{{ date('H') }}">

                        </div>
                        <!-- Checkbox to toggle password field -->
                        @if(auth()->user())



                        @else
                            <label class="checkbox-inline text-transform-capitalize">
                                <input id="create_account" type="checkbox" name="create_account" value="1"/>
                                Create an account for faster checkout in future
                            </label>
                        @endif

                        <!-- Password field (hidden by default) -->
                        <div class="col-sm-12 pt-3" id="password-field" style="display: none;">
                            <div class="form-wrap">
                                <input type="password" class="form-input" name="password" id="password" placeholder="Password">
                                <span class="error-message text-danger" id="error-password"></span>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-10 col-lg-6">
                        {{--<h3 class="fw-medium">Cart Items</h3>
                        <div class="table-custom-responsive">
                            <table class="table-custom table-custom-primary table-checkout">
                                <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Details</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach(session('cart', []) as $id => $item)
                                    <tr>
                                        <td>{{ $item['name'] }}</td>
                                        <td>
                                            @if(isset($item['variant_id']) && $item['variant_id'])
                                                Size: {{ $item['size'] ?? 'N/A' }}<br>
                                                @if($item['level'])
                                                    Message: {{ $item['level'] }}<br>
                                                @endif
                                            @endif
                                        </td>
                                        <td>{{ $item['quantity'] }}</td>
                                        <td>{{ number_format((float) $item['price'], 2) }} Tk</td>
                                        <td>{{ number_format((float) $item['price'] * (int) $item['quantity'], 2) }} Tk</td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>--}}

                        <h3 class="fw-medium mt-5">Payment Methods</h3>

                        @if($settings->payment_cod == 1)
                            <div class="box-radio">
                                <label class="radio-inline">
                                    <input name="payment_method" value="1" class="active" type="radio">Cash on Delivery
                                </label>
                                <p style="padding: 5px">Cash on Delivery. Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our <a href="https://www.mrbakerbd.com/page/privacy-policy">Privacy Policy</a>.</p>
                            </div>
                        @endif

                        @if($settings->payment_sslc == 1)
                            <div class="box-radio">
                                <label class="radio-inline">
                                    <input name="payment_method" value="2" class="active" type="radio" {{ $settings->payment_sslc == 1 ? 'checked' : '' }}>Pay Online
                                </label>
                                <p style="padding: 5px">Pay securely by bKash, Rocket, Nagad, Debit Cards, Credit Cards, Mobile Banking (8 Brands), Internet Banking (6 Banks) through SSLCommerz. Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our <a href="https://www.mrbakerbd.com/privacy-policy">Privacy Policy</a>.</p>
                            </div>
                        @endif
                        <span class="error-message text-danger" id="error-payment_method"></span>

                        @if(collect(session('cart', []))->isEmpty())
                            <div class="alert alert-warning">
                                Your cart is empty. Please add items to your cart before proceeding to checkout.
                            </div>
                        @else
                            <h3 class="fw-medium mt-5">Cart Total</h3>
                            <div class="table-custom-responsive">
                                @php
                                    $cartSubtotal = collect(session('cart', []))->reduce(function ($carry, $item) {
                                        return $carry + ((float) $item['price'] * (int) $item['quantity']);
                                    }, 0);

                                @endphp
                                <table class="table-custom table-custom-primary table-checkout">
                                    <tbody>
                                    <tr>
                                        <td>Cart Subtotal</td>
                                        <td>{{ number_format($cartSubtotal, 2) }} Tk</td>
                                    </tr>
                                    <tr>
                                        <td>Shipping</td>
                                        <td id="shipping-cost">{{ number_format($shipping, 2) }} Tk</td>
                                    </tr>
                                    <tr>
                                        <td>Total</td>
                                        <td id="total-cost">{{ number_format($cartSubtotal + $shipping, 2) }} Tk</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>

                            <label class="checkbox-inline text-transform-capitalize">
                                <input id="same-address" type="checkbox" name="conditions" value="yes" required/>
                                I have read and agree to the <a href="https://www.mrbakerbd.com/page/terms-conditions">Terms & Conditions</a> *
                                <span class="error-message text-danger" id="error-conditions"></span>
                            </label>

                            <div class="mt-4">
                                <button type="submit" class="button button-lg button-primary button-zakaria">
                                    Confirm Order
                                </button>
                            </div>
                    </div>
                    @endif
                </div>
            </form>
        </div>
    </section>
@endsection

   @section('page-scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const btn = document.getElementById('delv_t-dropdown-btn');
        const list = document.getElementById('delv_t-dropdown-list');
        const selected = document.getElementById('delv_t-selected');
        const hidden = document.getElementById('delv_t');

        btn.addEventListener('click', function(e) {
            e.preventDefault();
            list.style.display = list.style.display === 'block' ? 'none' : 'block';
        });

        list.querySelectorAll('.dropdown-item').forEach(function(item) {
            item.addEventListener('click', function() {
                selected.textContent = this.textContent;
                hidden.value = this.getAttribute('data-value');
                list.style.display = 'none';
            });
        });

        document.addEventListener('click', function(e) {
            if (!btn.contains(e.target) && !list.contains(e.target)) {
                list.style.display = 'none';
            }
        });
    });
         document.addEventListener('DOMContentLoaded', function() {
        // Reason dropdown logic
        const btn = document.getElementById('reason-dropdown-btn');
            const list = document.getElementById('reason-dropdown-list');
            const selected = document.getElementById('reason-selected');
            const hidden = document.getElementById('reason-hidden');
        btn.addEventListener('click', function(e) {
        e.preventDefault();
        list.style.display = list.style.display === 'block' ? 'none' : 'block';
        });
        list.querySelectorAll('.dropdown-item').forEach(function(item) {
        item.addEventListener('click', function() {
        selected.textContent = this.textContent;
        hidden.value = this.getAttribute('data-value');
        list.style.display = 'none';
        });
        });
        document.addEventListener('click', function(e) {
            if (!btn.contains(e.target) && !list.contains(e.target)) {
        list.style.display = 'none';
        }
        });

        // All time slots
        const allTimeSlots = [
        "08:00 AM - 09:00 AM",
        "09:00 AM - 10:00 AM",
        "10:00 AM - 11:00 AM",
        "11:00 AM - 12:00 PM",
        "12:00 PM - 01:00 PM",
        "01:00 PM - 02:00 PM",
        "02:00 PM - 03:00 PM",
        "03:00 PM - 04:00 PM",
        "04:00 PM - 05:00 PM",
        "05:00 PM - 06:00 PM",
        "06:00 PM - 07:00 PM",
        "07:00 PM - 08:00 PM",
        ];
            const serverDate = document.getElementById('server-date').value;
            const serverHour = parseInt(document.getElementById('server-time').value);

            function updateTimeSlots(selectedDate) {
            const $timeSelect = jQuery('#delv_t');
            $timeSelect.find('option:not(:first)').remove();
            let slotsToShow = [];
            if (selectedDate === serverDate) {
            slotsToShow = allTimeSlots.filter((slot, index) => serverHour < (4 + index));
        } else {
              slotsToShow = allTimeSlots;
          }
        slotsToShow.forEach(slot => {
            $timeSelect.append(`<option value="${slot}">${slot}</option>`);
        });
        }

        // Unified validation
        function validateForm() {
            let isValid = true;

        // Field definitions
        const fields = [
        {
            id: 'checkout-first-name-1',
            errorId: 'error-customer_name',
            validate: value => value.trim().length > 0,
            message: 'Name is required'
        },
        {
            id: 'address',
            errorId: 'error-address_details',
            validate: value => value.trim().length > 0,
            message: 'Address is required'
        },
        {
            id: 'checkout-email-1',
            errorId: 'error-email',
            validate: value => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value),
            message: 'Valid email is required'
        },
        {
            id: 'checkout-phone-1',
            errorId: 'error-phone',
            validate: value => /^\+?\d{10,}$/.test(value.replace(/\s/g, '')),
            message: 'Valid phone number is required'
        },
        {
            id: 'delv_d',
            errorId: 'error-delv_d',
            validate: value => value !== '',
            message: 'Delivery date is required'
        },
        {
            id: 'delv_t',
            errorId: 'error-time',
            validate: value => value !== '',
            message: 'Delivery time is required'
        },
        {
            id: 'same-address',
            errorId: 'error-conditions',
            validate: () => document.getElementById('same-address').checked,
        message: 'You must agree to the terms and conditions'
        }
        ];

        // Validate each field
        fields.forEach(f => {
            const input = document.getElementById(f.id);
            const errorElement = document.getElementById(f.errorId);
            let value = input.type === 'checkbox' ? input.checked : input.value;
            let valid = f.validate(value);
            if (!valid) {
        errorElement.textContent = f.message;
        errorElement.classList.add('active');
        input.classList.add('error');
            isValid = false;
        } else {
              errorElement.textContent = '';
              errorElement.classList.remove('active');
              input.classList.remove('error');
          }
        });

        // Validate reason dropdown
        const reason = document.getElementById('reason-hidden').value;
            const reasonError = document.getElementById('reason-error');
            if (!reason) {
        reasonError.style.display = 'block';
            isValid = false;
        } else {
              reasonError.style.display = 'none';
          }

        // Validate payment method
        const paymentMethod = document.querySelector('input[name="payment_method"]:checked');
            const paymentError = document.getElementById('error-payment_method');
            if (!paymentMethod) {
        paymentError.textContent = 'Please select a payment method';
        paymentError.classList.add('active');
            isValid = false;
        } else {
              paymentError.textContent = '';
              paymentError.classList.remove('active');
          }

        // Validate password if create account is checked
        const createAccount = document.getElementById('create_account') && document.getElementById('create_account').checked;
            if (createAccount) {
            const password = document.getElementById('password');
            const passwordError = document.getElementById('error-password');
            if (password.value.length < 8) {
        passwordError.textContent = 'Password must be at least 8 characters long';
        passwordError.classList.add('active');
        password.classList.add('error');
            isValid = false;
        } else {
              passwordError.textContent = '';
              passwordError.classList.remove('active');
              password.classList.remove('error');
          }
        } else if (document.getElementById('error-password')) {
        document.getElementById('error-password').textContent = '';
        document.getElementById('error-password').classList.remove('active');
            if (document.getElementById('password')) {
        document.getElementById('password').classList.remove('error');
        }
        }

            return isValid;
        }

        // Real-time validation
        jQuery(document).ready(function () {
            const defaultDate = jQuery('#delv_d').val();
        updateTimeSlots(defaultDate);

        // Real-time for all fields
        [
        'checkout-first-name-1',
        'address',
        'checkout-email-1',
        'checkout-phone-1',
        'delv_d',
        'delv_t'
        ].forEach(id => {
        jQuery(`#${id}`).on('input change', function() {
        validateForm();
        });
        });

        jQuery('#same-address').on('change', function() {
        validateForm();
        });

        jQuery('input[name="payment_method"]').on('change', function() {
        validateForm();
        });

        jQuery('#password').on('input', function() {
        validateForm();
        });

        jQuery('#delv_d').on('change', function () {
        updateTimeSlots(this.value);
        validateForm();
        });

        // Show/hide password field
        if (document.getElementById('create_account')) {
        document.getElementById('create_account').addEventListener('change', function () {
            var passwordField = document.getElementById('password-field');
        passwordField.style.display = this.checked ? 'block' : 'none';
        validateForm();
        });
        }

        // Unified form submit
        jQuery('#checkout-form').on('submit', function(e) {
            if (!validateForm()) {
        e.preventDefault();
        e.stopImmediatePropagation();
            return false;
        }
        });
        });
        });
        </script>
@endsection
